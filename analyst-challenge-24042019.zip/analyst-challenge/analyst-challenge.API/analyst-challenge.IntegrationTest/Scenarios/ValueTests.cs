﻿using System.Net;
using System.Threading.Tasks;
using analyst_challenge.IntegrationTest.Fixtures;
using FluentAssertions;
using Xunit;

namespace analyst_challenge.IntegrationTest.Scenarios
{
    public class ValueTests
    {
        public class ValuesTest
        {
            private readonly TestContext _testContext;
            public ValuesTest()
            {
                _testContext = new TestContext();
            }

            [Fact]
            public async Task Values_Get_ReturnsOkResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento");
                response.EnsureSuccessStatusCode();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            [Fact]
            public async Task Values_RecuperarPorId_ValuesReturnsOkResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/5");
                response.EnsureSuccessStatusCode();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            [Fact]
            public async Task Values_RecuperarPorId_ReturnsBadRequestResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/XXX");
                response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            }

            //[Fact]
            //public async Task Values_RecuperarPorId_CorrectContentType()
            //{
            //    var response = await _testContext.Client.GetAsync("/api/Evento/5");
            //    response.EnsureSuccessStatusCode();
            //    response.Content.Headers.ContentType.ToString().Should().Be("text/plain; charset=utf-8");
            //}
            [Fact]
            public async Task Values_RecuperarPorTag_ValuesReturnsOkResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorTag/brasil.sudeste.sensor01");
                response.EnsureSuccessStatusCode();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            [Fact]
            public async Task Values_RecuperarPorTag_ReturnsBadRequestResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorTag/");
                response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            }

            [Fact]
            public async Task Values_RecuperarPorTimeStamp_ValuesReturnsOkResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorTimeStamp/1539112021301");
                response.EnsureSuccessStatusCode();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            [Fact]
            public async Task Values_RecuperarPorTimeStamp_ReturnsBadRequestResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorTimeStamp/XXX");
                response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            }

            [Fact]
            public async Task Values_RecuperarPorValor_ValuesReturnsOkResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorValor/200");
                response.EnsureSuccessStatusCode();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            [Fact]
            public async Task Values_RecuperarPorValor_ReturnsBadRequestResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorValor/");
                response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            }

            [Fact]
            public async Task Values_RecuperarPorStatus_ValuesReturnsOkResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorStatus/1");
                response.EnsureSuccessStatusCode();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            [Fact]
            public async Task Values_RecuperarPorStatus_ReturnsBadRequestResponse()
            {
                var response = await _testContext.Client.GetAsync("/api/Evento/RecuperarPorStatus/XXX");
                response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            }


        }

    }
}
