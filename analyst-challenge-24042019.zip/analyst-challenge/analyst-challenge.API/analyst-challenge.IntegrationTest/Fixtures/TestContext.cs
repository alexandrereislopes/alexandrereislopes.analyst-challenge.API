﻿using System.IO;
using System.Net.Http;
using analyst_challenge.Application;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;

namespace analyst_challenge.IntegrationTest.Fixtures
{
    public class TestContext
    {
        public HttpClient Client { get; set; }
        private TestServer _server;

        public TestContext()
        {
            SetupClient();
        }

        public void SetupClient()
        {
            _server = new TestServer(new WebHostBuilder()
                                        .UseConfiguration(new ConfigurationBuilder()
                                                            //.SetBasePath(Directory.GetCurrentDirectory())
                                                            .AddJsonFile("appsettings.json")
                                                            .Build()
                                    ).UseStartup<Startup>());

            Client = _server.CreateClient();

        }
    }
}
