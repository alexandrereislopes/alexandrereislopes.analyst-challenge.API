﻿using analyst_challenge.Domain.Interfaces.Repositories;
using analyst_challenge.Domain.Interfaces.Services;
using analyst_challenge.Infra.Context;
using analyst_challenge.Infra.Repositories;
using analyst_challenge.Service;
using Microsoft.Extensions.DependencyInjection;

namespace analyst_challenge.Infra.IoC
{
    public static class DIContainer
    {
        public static void RegisterDependencies(IServiceCollection services)
        {
            services.AddScoped<ACContext>();

            services.AddTransient<IEventoService, EventoService>();
            services.AddTransient<IEventoRepository, EventoRepository>();
        }
    }
}
