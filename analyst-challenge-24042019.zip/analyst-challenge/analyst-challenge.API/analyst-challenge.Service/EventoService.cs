﻿using System;
using System.Collections.Generic;
using analyst_challenge.Domain.Enums;
using analyst_challenge.Domain.Interfaces.Repositories;
using analyst_challenge.Domain.Interfaces.Services;
using analyst_challenge.Domain.Models;

namespace analyst_challenge.Service
{
    public class EventoService : BaseService<Evento>, IEventoService
    {
        private readonly IEventoRepository _repository;

        public EventoService(IEventoRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public void Incluir(Evento obj)
        {
            Evento campos = (Evento)obj;
            campos.status = Convert.ToUInt16(StatusEnum.ERRO);

            if (!string.IsNullOrWhiteSpace(campos.valor))
                campos.status = Convert.ToUInt16(StatusEnum.PROCESSADO);

            _repository.Incluir(campos);
        }

        public List<Evento> RecuperarPorTimeStamp(Int64 timeStamp)
        {
            return _repository.RecuperarPorTimeStamp(timeStamp);
        }
        public List<Evento> RecuperarPorStatus(int status)
        {
            return _repository.RecuperarPorStatus(status);
        }
        public List<Evento> RecuperarPorTag(string tag)
        {
            return _repository.RecuperarPorTag(tag);
        }
        public List<Evento> RecuperarPorValor(string valor)
        {
            return _repository.RecuperarPorValor(valor);
        }
    }
}
