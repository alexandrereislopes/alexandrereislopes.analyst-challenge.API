﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using analyst_challenge.Domain.Interfaces.Services;
using analyst_challenge.Domain.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace analyst_challenge.Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventoController : ControllerBase
    {
        private readonly IEventoService _service;
        public EventoController(IEventoService service)
        {
            _service = service;
        }

        // GET: api/Evento
        [HttpGet]
        public IEnumerable<Evento> Get()
        {
            return _service.Listar();
        }

        // GET: api/Evento/5
        [HttpGet("{id}", Name = "RecuperarPorId")]
        public object RecuperarPorId(int id)
        {
            return _service.RecuperarPorId(id);
        }

       // GET: api/Evento/brasil.sudeste.sensor01
       [HttpGet("RecuperarPorTag/{tag}", Name = "RecuperarPorTag")]
        public object RecuperarPorTag(string tag)
        {
            return _service.RecuperarPorTag(tag);
        }

        // GET: api/Evento/RecuperarPorTimeStamp/1539112021301
        [HttpGet("RecuperarPorTimeStamp/{timeStamp}", Name = "RecuperarPorTimeStamp")]
        public object RecuperarPorTimeStamp(Int64 timeStamp)
        {
            return _service.RecuperarPorTimeStamp(timeStamp);
        }
        
        // GET: api/Evento/RecuperarPorValor/333
        [HttpGet("RecuperarPorValor/{valor}", Name = "RecuperarPorValor")]
        public object RecuperarPorValor(string valor)
        {
            return _service.RecuperarPorValor(valor);
        }

        // GET: api/Evento/RecuperarPorStatus/1
        [HttpGet("RecuperarPorStatus/{status}", Name = "RecuperarPorStatus")]
        public object RecuperarPorStatus(int status)
        {
            return _service.RecuperarPorStatus(status);
        }
        // POST: api/Evento
        [HttpPost]
        public void Post([FromBody] Evento model)
        {
            _service.Incluir(model);
        }

        // PUT: api/Evento/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _service.Excluir(id);
        }
    }
}
