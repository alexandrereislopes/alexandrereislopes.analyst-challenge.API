﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using analyst_challenge.Domain.Enums;
using analyst_challenge.Domain.Interfaces.Repositories;
using analyst_challenge.Domain.Models;
using analyst_challenge.Infra.Context;

namespace analyst_challenge.Infra.Repositories
{
    public class EventoRepository : BaseRepository<Evento>, IEventoRepository
    {
        public EventoRepository(ACContext context) : base(context)
        {
        }

        public List<Evento> RecuperarPorTimeStamp(Int64 timeStamp)
        {
            return Db.Set<Evento>().Where(p => p.timeStamp == timeStamp).ToList();
        }
        public List<Evento> RecuperarPorTag(string tag)
        {
            return Db.Set<Evento>().Where(p => p.tag == tag.ToUpper()).ToList();
        }
        public List<Evento> RecuperarPorValor(string valor)
        {
            return Db.Set<Evento>().Where(p => p.valor == valor.ToUpper()).ToList();
        }
        public List<Evento> RecuperarPorStatus(int status)
        {
            return Db.Set<Evento>().Where(p => p.status == status).ToList();
        }

    }
}
