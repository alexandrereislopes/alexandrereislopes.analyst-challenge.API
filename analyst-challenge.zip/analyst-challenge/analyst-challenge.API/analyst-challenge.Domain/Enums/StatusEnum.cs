﻿using System;
using System.Collections.Generic;
using System.Text;

namespace analyst_challenge.Domain.Enums
{
    public enum StatusEnum
    {
        ERRO = 0,
        PROCESSADO = 1
    }
}
