﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using analyst_challenge.Domain.Models;

namespace analyst_challenge.Domain.Interfaces.Repositories
{
    public interface IEventoRepository : IBaseRepository<Evento>
    {
        List<Evento> RecuperarPorTimeStamp(Int64 timeStamp);
        List<Evento> RecuperarPorTag(string tag);
        List<Evento> RecuperarPorValor(string valor);
        List<Evento> RecuperarPorStatus(int status);
    }
}
