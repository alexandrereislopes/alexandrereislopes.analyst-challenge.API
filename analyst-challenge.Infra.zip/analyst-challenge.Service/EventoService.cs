﻿using System;
using System.Collections.Generic;
using System.Text;
using analyst_challenge.Domain.Interfaces.Repositories;
using analyst_challenge.Domain.Interfaces.Services;
using analyst_challenge.Domain.Models;

namespace analyst_challenge.Service
{
    public class EventoService : BaseService<Evento>, IEventoService
    {
        public EventoService(IEventoRepository repository) : base(repository)
        {
        }
    }
}
