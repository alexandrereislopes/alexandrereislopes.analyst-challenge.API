﻿using System;
using System.Collections.Generic;
using System.Text;
using analyst_challenge.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace analyst_challenge.Infra.Configurations
{
    public class EventoConfiguration : IEntityTypeConfiguration<Evento>
    {
        public void Configure(EntityTypeBuilder<Evento> builder)
        {
            //Propriedades
            builder.Property(p => p.id).UseSqlServerIdentityColumn();
            builder.Property(p => p.timeStamp).IsRequired();
            builder.Property(p => p.tag).HasColumnType("varchar(200)").HasMaxLength(200).IsRequired();
            builder.Property(p => p.valor).HasColumnType("varchar(200)").HasMaxLength(200).IsRequired();
            
            //Chaves
            builder.HasKey(p => p.id).HasName("PK_Evento");
        }
    }
}
