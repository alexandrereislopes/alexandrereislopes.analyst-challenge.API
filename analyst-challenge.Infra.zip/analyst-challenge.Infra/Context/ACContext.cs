﻿using System;
using System.Collections.Generic;
using System.Text;
using analyst_challenge.Domain.Models;
using analyst_challenge.Infra.Configurations;
using Microsoft.EntityFrameworkCore;

namespace analyst_challenge.Infra.Context
{
    public class ACContext: DbContext
    {
        public ACContext(DbContextOptions<ACContext> options)
            : base(options)
        { }

        public DbSet<Evento> Evento { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new EventoConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}
