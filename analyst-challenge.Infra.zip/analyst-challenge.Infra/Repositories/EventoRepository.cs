﻿using System;
using System.Collections.Generic;
using System.Text;
using analyst_challenge.Domain.Interfaces.Repositories;
using analyst_challenge.Domain.Models;
using analyst_challenge.Infra.Context;

namespace analyst_challenge.Infra.Repositories
{
    public class EventoRepository : BaseRepository<Evento>, IEventoRepository
    {
        public EventoRepository(ACContext context) : base(context)
        {
        }
    }
}
