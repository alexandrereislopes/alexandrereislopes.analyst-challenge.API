﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using analyst_challenge.Domain.Interfaces.Repositories;
using analyst_challenge.Infra.Context;
using Microsoft.EntityFrameworkCore;

namespace analyst_challenge.Infra.Repositories
{
    public abstract class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        protected ACContext Db;
        public BaseRepository(ACContext context)
        {
            Db = context;
        }
        public void Alterar(T obj)
        {
            Db.Entry(obj).State = EntityState.Modified;
            Db.SaveChanges();
        }

        public void Excluir(int id)
        {
            var entity = RecuperarPorId(id);
            Db.Set<T>().Remove(entity);
            Db.SaveChanges();
        }

        public void Incluir(T obj)
        {
            Db.Set<T>().Add(obj);
            Db.SaveChanges();
        }

        public List<T> Listar()
        {
            return Db.Set<T>().ToList();
        }

        public T RecuperarPorId(int id)
        {
            return Db.Set<T>().Find(id);
        }
    }
}
