﻿using System;

namespace analyst_challenge.Domain.Models
{
    public class Evento
    {
        public int id { get; set; }

        public int timeStamp { get; set; }

        public string tag { get; set; }

        public string valor { get; set; }
    }
}
