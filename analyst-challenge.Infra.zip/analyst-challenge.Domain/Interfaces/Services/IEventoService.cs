﻿using System;
using System.Collections.Generic;
using System.Text;
using analyst_challenge.Domain.Models;

namespace analyst_challenge.Domain.Interfaces.Services
{
    public interface   IEventoService : IBaseService<Evento>
    {
    }
}
