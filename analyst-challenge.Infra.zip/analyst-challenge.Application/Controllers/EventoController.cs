﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using analyst_challenge.Domain.Interfaces.Services;
using analyst_challenge.Domain.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace analyst_challenge.Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventoController : ControllerBase
    {
        private readonly IEventoService _service;
        public EventoController(IEventoService service)
        {
            _service = service;
        }

        // GET: api/Evento
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Evento/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Evento
        [HttpPost]
        public void Post([FromBody] Evento model)
        {
            _service.Incluir(model);
        }

        // PUT: api/Evento/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
